package chrriis.dj.nativeswing.swtimpl.core;

interface NoSerializationTestMessage {

}
