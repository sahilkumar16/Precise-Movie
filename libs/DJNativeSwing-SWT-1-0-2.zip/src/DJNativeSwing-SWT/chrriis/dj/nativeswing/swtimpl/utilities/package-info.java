/*
 * Christopher Deckers (chrriis@nextencia.net)
 * http://www.nextencia.net
 *
 * See the file "readme.txt" for information on usage and redistribution of
 * this file, and for a DISCLAIMER OF ALL WARRANTIES.
 */

/**
 * A collection of native utilities.
 * @author Christopher Deckers
 */
package chrriis.dj.nativeswing.swtimpl.utilities;
