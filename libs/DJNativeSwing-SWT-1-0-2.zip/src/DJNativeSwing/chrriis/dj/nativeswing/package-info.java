/*
 * Christopher Deckers (chrriis@nextencia.net)
 * http://www.nextencia.net
 *
 * See the file "readme.txt" for information on usage and redistribution of
 * this file, and for a DISCLAIMER OF ALL WARRANTIES.
 */

/**
 * The framework, containing all the core classes that make the native integration possible.
 * @author Christopher Deckers
 */
package chrriis.dj.nativeswing;
